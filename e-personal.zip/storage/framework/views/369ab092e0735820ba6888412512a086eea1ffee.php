<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section id="wrapper" class="error-page">
    <div class="error-box">
        <div class="error-body text-center">
            <h1>500</h1>
            <h3 class="text-uppercase">Terjadi Kesalahan  !</h3>
            <p class="text-muted m-t-30 m-b-30">SEPERTINYA SERVER MEMBUTUHKAN WAKTU TERLALU LAMA UNTUK MERESPON</p>
            <a href="<?php echo e(route('home')); ?>" class="btn btn-info btn-rounded waves-effect waves-light m-b-40">Back to home</a> </div>
        <footer class="footer text-center">2019 | Dric</footer>
    </div>
</section>

<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\xampp\htdocs\e-personal\resources\views/errors/500.blade.php ENDPATH**/ ?>