<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="fix-header fix-sidebar card-no-border">

    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> 
        </svg>
    </div>

    <div id="main-wrapper">

        <header class="topbar">

            <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </header>

        <aside class="left-sidebar">

            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </aside>

        <div class="page-wrapper">

            <div class="row">
                <div class="col-md-4 offset-md-4">
                    <?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>   
            </div>
            
            <?php echo $__env->yieldContent('content'); ?>

            <footer class="footer text-center">
                © 2019 | Dric
            </footer>

        </div>
    </div>

    <?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('extra_script'); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\e-personal\resources\views/layouts/main.blade.php ENDPATH**/ ?>