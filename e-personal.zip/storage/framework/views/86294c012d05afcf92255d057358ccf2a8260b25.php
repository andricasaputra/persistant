<!-- ============================================================== -->
<!-- All Jquery -->
<!-- ============================================================== -->
<script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="<?php echo e(asset('plugins/bootstrap/js/tether.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="<?php echo e(asset('js/jquery.slimscroll.js')); ?>"></script>
<!--Wave Effects -->
<script src="<?php echo e(asset('js/waves.js')); ?>"></script>
<!--Menu sidebar -->
<script src="<?php echo e(asset('js/sidebarmenu.js')); ?>"></script>
<!--stickey kit -->
<script src="<?php echo e(asset('plugins/sticky-kit-master/dist/sticky-kit.min.js')); ?>"></script>
<!--Custom JavaScript -->
<script src="<?php echo e(asset('js/custom.min.js')); ?>"></script>
<!-- ============================================================== -->
<!-- This page plugins -->
<!-- ============================================================== -->
<!-- Flot Charts JavaScript -->
<script src="<?php echo e(asset('plugins/flot/jquery.flot.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/flot.tooltip/js/jquery.flot.tooltip.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/flot-data.js')); ?>"></script>
<!-- ============================================================== -->
<!-- Style switcher -->
<!-- ============================================================== -->
<script src="<?php echo e(asset('plugins/styleswitcher/jQuery.style.switcher.js')); ?>"></script>

<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\e-personal\resources\views/layouts/script.blade.php ENDPATH**/ ?>