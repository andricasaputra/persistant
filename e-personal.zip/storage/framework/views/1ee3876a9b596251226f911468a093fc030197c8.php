<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>E-Personal Helper</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    </head>
    <body>
        <div class="container">
           <form enctype='multipart/form-data' action="<?php echo e(route('store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <label for="filenya">Upload File</label>
                <input type=file name='filenya' size=40>

                <button type="submit">Upload</button>
            </form>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\e-personal\resources\views/store.blade.php ENDPATH**/ ?>