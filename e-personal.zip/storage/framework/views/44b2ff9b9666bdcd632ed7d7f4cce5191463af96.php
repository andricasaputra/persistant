<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>






<script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous">
  	
  </script>

<script>
	
var name = "codemzy";
var url = "http://anyorigin.com/go?url=" + encodeURIComponent("https://laravel.com/");
$.get(url, function(response) {  
	console.log(response);
});
</script>
</body>
</html><?php /**PATH C:\xampp\htdocs\e-personal\resources\views/ajax.blade.php ENDPATH**/ ?>