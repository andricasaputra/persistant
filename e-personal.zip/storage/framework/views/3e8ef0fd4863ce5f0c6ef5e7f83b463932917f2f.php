<?php $__env->startSection('content'); ?>
    
    <style>
        label{
            font-weight: bold!important;
        }
    </style>

    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="row page-titles">
            <div class="col-md-6 col-8 align-self-center">
                <h3 class="text-themecolor m-b-0 m-t-0">Upload</h3>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                    <li class="breadcrumb-item active">Upload Aktivitas</li>
                </ol>
            </div>
            <div class="col-md-6 col-4 align-self-center">
                <a href="<?php echo e(route('home')); ?>" class="btn pull-right hidden-sm-down btn-success"> Go to Dashboard</a>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <!-- Row -->
        <div class="row">
            <!-- Column -->
            <!-- Column -->
            <!-- Column -->
            <div class="col-lg-8 col-xlg-9 col-md-7 mx-auto">
                <div class="card">
                    <div class="card-block">
                         <form enctype='multipart/form-data' action="<?php echo e(route('create')); ?>" method="post" class="form-horizontal form-material">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label class="col-md-12 m-b-30">Tanggal</label>
                                <input type="date" class="form-control" name="bulan" value="<?php echo e(date('Y-m-d')); ?>">
                            </div>
                            <div class="form-group">
                                <label class="col-md-12 m-b-30">Pilih Butir Kegiatan</label>
                                <select id="butir_kegiatan" class="form-control" name="butir_kegiatan" style="width:auto;">
                                    <option value="-">Pilih Butir</option>
                                </select>
                            </div>
                            <div class="form-group" >
                                <div id="detail_nilai" class="form-group form-inline col-md-12"></div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-12 m-b-30">Pilih File</label>
                                <div class="col-md-12">
                                    <input type="file" name="filenya" class="form-control form-control-line">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <button class="btn btn-success"><b>Upload</b></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- Column -->
        </div>
        <!-- Row -->
        <!-- ============================================================== -->
        <!-- End PAge Content -->
        <!-- ============================================================== -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_script'); ?>

<script>

    const baseUrl = 'http://ekinerja.pertanian.go.id/epersonalv2/ekinerjav2/mlog/';

    const skpBulanUrl = baseUrl + 'getSkpBulan.php';

    const kuantitasUrl = baseUrl + 'getKuantitas.php';

    const proxy = 'https://cors-anywhere.herokuapp.com/';

    let nip = $('a#profileNav').data('src');

    let tanggal = $('input[name="bulan"]');

    function getSkpBulanNew(tanggal) {

        $.ajax({
            url: proxy + skpBulanUrl,
            data: {"tanggal": tanggal,"nip": nip},
            type: "GET",
            success: function(data){
                $('#butir_kegiatan').empty();
                
                $('#butir_kegiatan').html(data);
            }
        });

    }

    getSkpBulanNew(tanggal.val());

    // Panggil butir kergiatan sesuai tanggal yang dipilih
    $(tanggal).on('change', function(){

        getSkpBulanNew($(this).val());

    });

    // Panggil kuantitas sesuai butir kegiatan yang dipilih
    $('#butir_kegiatan').on('change', function(){

        let id = $(this).val();

        $('#detail_nilai')
        .html('<div style="margin: auto"><i class="fa fa-spin fa-spinner"></i></div>')
        .load(proxy + kuantitasUrl + '?id=' + id);

    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-personal\resources\views/upload.blade.php ENDPATH**/ ?>