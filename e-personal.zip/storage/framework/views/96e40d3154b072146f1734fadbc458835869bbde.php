<script>

	  $.extend( true, $.fn.dataTable.defaults, {
	    language: {
	        "sEmptyTable":   "Tidak ada data yang tersedia pada tabel ini",
	        "sProcessing":   "Sedang memproses...",
	        "sLengthMenu":   "Tampilkan _MENU_ entri",
	        "sZeroRecords":  "Tidak ditemukan data yang sesuai",
	        "sInfo":         "Menampilkan _START_ sampai _END_ dari _TOTAL_ entri",
	        "sInfoEmpty":    "Menampilkan 0 sampai 0 dari 0 entri",
	        "sInfoFiltered": "(disaring dari _MAX_ entri keseluruhan)",
	        "sInfoPostFix":  "",
	        "sSearch":       "Cari:",
	        "sUrl":          "",
	        "oPaginate": {
	          "sFirst":    "Pertama",
	          "sPrevious": "Sebelumnya",
	          "sNext":     "Selanjutnya",
	          "sLast":     "Terakhir"
	        }
	    }
	  });

	  let nip = <?php echo e($profile['nip']); ?>;

	  let bulan = '';

	  let tahun = '';

	  let key = '';

	  const proxy = 'https://cors-anywhere.herokuapp.com/';

	  const baseUrl = 'http://ekinerja.pertanian.go.id/epersonalv2/';

	  const logUrl = baseUrl + 'ekinerjav2/mlog/';

	  const docUrl = 'http://ekinerja.pertanian.go.id/epersonalv2/' + 'doc/log/';

	  const sptUrl = 'http://ekinerja.pertanian.go.id/epersonalv2/' + 'doc/log/spt/';

	  const secureUrl = proxy + baseUrl;

	  let logApiUrl = secureUrl + `ekinerjav2/mlog/index_json.php?nip=${nip}&bulan=${bulan}&tahun=${tahun}&key=${key}`;

	  

</script><?php /**PATH C:\xampp\htdocs\e-personal\resources\views/inc/script.blade.php ENDPATH**/ ?>