<?php $__env->startSection('content'); ?>

<div class="container-login100">
    <div class="wrap-login100">

        <form class="validate-form" method="POST" action="<?php echo e(route('password.email')); ?>" style="width: 100%; margin: auto;">

             <?php echo csrf_field(); ?>

             <?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

              <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
             <?php endif; ?>

            <span class="login100-form-title">
                Reset Password
            </span>

            <div class="wrap-input100 validate-input">
                <input class="input100" id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" autofocus placeholder="Email Address" autocomplete="none" required>
                <span class="focus-input100"></span>
                <span class="symbol-input100">
                    <i class="fa fa-envelope" aria-hidden="true"></i>
                </span>
            </div>

             <div class="container-login100-form-btn">
                <button class="login100-form-btn">
                     <?php echo e(__('Send Password Reset Link')); ?>

                </button>
            </div>

            <div class="text-center p-t-136">
                <a class="txt2" href="<?php echo e(route('login')); ?>">
                    <i class="fa fa-long-arrow-left m-l-5" aria-hidden="true"></i>
                    Back to login
                </a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-personal\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>