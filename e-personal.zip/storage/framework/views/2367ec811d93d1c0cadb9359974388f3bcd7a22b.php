<?php $__env->startSection('content'); ?>

<div class="container-login100">
    <div class="wrap-login100 text-center">

        <form class="validate-form" autocomplete="off" method="POST" action="<?php echo e(route('register')); ?>" style="margin: auto; width: 100%; margin-left: 6%">

             <?php echo csrf_field(); ?>

             <?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <span class="login100-form-title">
                Register
            </span>

            <div class="wrap-input100 validate-input text-center">
                <input class="input100" id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>"  placeholder="Username" autocomplete="none" required>
                <span class="focus-input100"></span>
                <span class="symbol-input100">
                    <i class="fa fa-user" aria-hidden="true"></i>
                </span>
            </div>

            <div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
                <input class="input100" id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required placeholder="Email Address">
                <span class="focus-input100"></span>
                <span class="symbol-input100">
                    <i class="fa fa-envelope" aria-hidden="true"></i>
                </span>
            </div>

            <div class="wrap-input100 validate-input" data-validate = "Password is required">
                <input class="input100" id="password" type="password" name="password" required placeholder="Password">
                <span class="focus-input100"></span>
                <span class="symbol-input100">
                    <i class="fa fa-lock" aria-hidden="true"></i>
                </span>
            </div>

            <div class="wrap-input100 validate-input" data-validate = "Password Confirmation is required">
                <input class="input100" type="password" name="password_confirmation" required  placeholder="Password Confirmation">
                <span class="focus-input100"></span>
                <span class="symbol-input100">
                    <i class="fa fa-lock" aria-hidden="true"></i>
                </span>
            </div>
            
            <div class="container-login100-form-btn">
                <button class="login100-form-btn">
                    Register
                </button>
            </div>

            <div class="text-center p-t-12">
                <span class="txt1">
                    Already have account?
                </span>
                <a class="txt2" href="<?php echo e(route('login')); ?>">
                   Login
                </a>
            </div>

            <div class="text-center p-t-136">
                <a class="txt2" href="<?php echo e(route('login')); ?>">
                    <i class="fa fa-long-arrow-left m-l-5" aria-hidden="true"></i>
                    Back to login
                </a>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-personal\resources\views/auth/register.blade.php ENDPATH**/ ?>