<?php  

namespace App\Repositories;

use Goutte\Client;

class Profile
{
	public function show()
	{
		return app('Profile');
	}
}