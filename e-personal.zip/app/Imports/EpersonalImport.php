<?php

namespace App\Imports;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;

class EpersonalImport implements ToCollection, WithMultipleSheets, WithHeadingRow
{
	private $rows;

    /**
    * @param Collection $collection
    */
    public function collection(Collection $rows)
    {
    	$this->rows = $this->prepare($rows);

        return $this->prepare($rows);
    }

    public function getRows()
    {
    	return $this->rows;
    }

    /**
     * Mengambil sheet pertama saja pada dokumen excel
     *
     * @return array
     */
    public function sheets(): array
    {
        return [0 => $this];
    }

    /**
     * Mengambil data dari row ke 7, 
     * row ke 7 adalah header, row ke 8 dst adalah data
     *
     * @return int
     */
    public function headingRow(): int
    {
        return 1;
    }

    public function prepare($rows)
    {
    	return $rows->map(function($row){

    		$row["tanggal"] = $this->transformDate($row["tanggal"])->toDateString();

    		return $row;
    	});
    }

    /**
	 * Transform tanggal menjadi object dari carbon
	 *
	 * @param string $value
	 * @param string $format
	 * @return \Carbon\Carbon|null
	 */
	protected function transformDate($value, $format = 'Y-m-d')
	{
	    try {

	        return Carbon::instance(\PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($value));

	    } catch (\ErrorException $e) {

	        return Carbon::createFromFormat($format, $value);
	    }
	}
}
