<?php

namespace App\Providers;

use Goutte\Client;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;
use App\Http\View\Composer\ProfileComposer;

class AppServiceProvider extends ServiceProvider
{
    protected $loginUri = 'http://ekinerja.pertanian.go.id/epersonalv2/index.php';

    protected $profileUri = 'http://ekinerja.pertanian.go.id/epersonalv2/mpribadi/index.php';

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->login();    

        $this->logout(); 

        $this->getProfile();
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(191);

        View::composer(['home', 'profile', 'log', 'layouts.navbar'], ProfileComposer::class);
    }

    private function login()
    {
        $this->app->singleton(Client::class, function($app) {

            $client =  new Client;

            $crawler = $client->request('GET', $this->loginUri);

            $form = $crawler->selectButton('Login')->form();

            $form['admin'] = auth()->user()->name;
            
            $form['kunci'] = auth()->user()->e_password;

            $client->submit($form);

            return $client;

        });
    }

    private function logout()
    {
        $this->app->singleton('Logout', function($app) {

            $client = $app[Client::class];

            $crawler = $client->request('GET', $this->profileUri);

            $link = $crawler->filterXpath('//*[@id="side-menu"]/li[10]/a')->link();

            return $client->click($link);

        });
    }

    private function getProfile()
    {
        $this->app->singleton('Profile', function($app) {

            $client = $app[Client::class];

            try {
        
                $crawler = $client->request('GET', $this->profileUri);

                $datas = $crawler->filter('table')->filter('tr')->each(function ($tr, $i) {

                    return $tr->filter('td')->each(function ($td, $i) {

                          return $td->filter('td')->text();
                    });

                });

                $image = $crawler->filter('img')->eq(2)->attr('src');

                $result = [];

                foreach ($datas as $data) {
                    if (! empty($data)) {
                        $result += [strtolower(str_replace(' ', '_', $data[0])) => $data[2]];
                    }
                }

                $result += ['foto' => $image];

                return $result;

            } catch (\InvalidArgumentException $e) {

                return abort('500');

            }

        });
    }
}
