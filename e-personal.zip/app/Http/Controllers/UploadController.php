<?php

namespace App\Http\Controllers;

use App\Repositories\Upload;
use App\Http\Requests\UploadRequest;

class UploadController extends Controller
{
	protected $destinationUri = 'http://ekinerja.pertanian.go.id/epersonalv2/ekinerjav2/mlog/index.php';

	public function __construct()
	{
		$this->middleware('doNotCacheResponse')->only('upload');
	}

    public function upload()
	{
		return view('upload');
	}

	public function create(UploadRequest $request)
	{
		$upload = (new Upload)->create($this->destinationUri);

		if ($upload === false) {

			return back()->withWarning("Terjadi kesalahan pada server, silahkan coba beberapa saat lagi");
		}

		return back()->withSuccess("$upload data berhasil diupload ke E-Personal anda");
	}
}
