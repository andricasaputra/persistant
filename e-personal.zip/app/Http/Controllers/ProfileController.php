<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Repositories\Profile;

class ProfileController extends Controller
{
	public function __construct()
	{
		$this->middleware('doNotCacheResponse')->only('log');
	}

    public function index()
    {
    	return view('profile');
    }

    public function log()
    {
    	return view('log');
    }
}
