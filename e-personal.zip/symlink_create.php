<?php 

// $linkName = '/home/username/public_html/mydomain.com/public/myfolder1';

// $target = '/home/username/public_html/mydomain.com/storage/app/public/myfolder1';

// symlink($target, $linkName);

symlink('/home/skph4384/e-personal/storage/app/public', '/home/skph4384/public_html/e-personal/storage');